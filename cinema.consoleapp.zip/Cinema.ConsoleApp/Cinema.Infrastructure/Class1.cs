﻿namespace Cinema.Infrastructure
{
    public class Class1
    {

    }
}
