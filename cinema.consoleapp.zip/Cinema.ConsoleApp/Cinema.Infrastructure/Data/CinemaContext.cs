﻿using Cinema.Domain.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;

namespace Cinema.Infrastructure.Data;

public class CinemaContext : DbContext
{
    public DbSet<Movie> Movies => Set<Movie>();
    public DbSet<MovieDetails> MovieDetails => Set<MovieDetails>();
    public DbSet<Hall> Halls => Set<Hall>();
    public DbSet<Session> Sessions => Set<Session>();
    public DbSet<Ticket> Tickets => Set<Ticket>();

    public CinemaContext(DbContextOptions<CinemaContext> options)
        : base(options) { }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        // Movie 1–1 MovieDetails
        modelBuilder.Entity<Movie>()
            .HasOne(m => m.Details)
            .WithOne(d => d.Movie)
            .HasForeignKey<MovieDetails>(d => d.Id);

        // Movie 1–many Sessions
        modelBuilder.Entity<Movie>()
            .HasMany(m => m.Sessions)
            .WithOne(s => s.Movie)
            .HasForeignKey(s => s.MovieId);

        // Hall 1–many Sessions
        modelBuilder.Entity<Hall>()
            .HasMany(h => h.Sessions)
            .WithOne(s => s.Hall)
            .HasForeignKey(s => s.HallId);

        // Session 1–many Tickets
        modelBuilder.Entity<Session>()
            .HasMany(s => s.Tickets)
            .WithOne(t => t.Session)
            .HasForeignKey(t => t.SessionId);
    }
}