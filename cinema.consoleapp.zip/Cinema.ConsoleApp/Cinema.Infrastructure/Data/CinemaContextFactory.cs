﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Design;

namespace Cinema.Infrastructure.Data;

public class CinemaContextFactory
    : IDesignTimeDbContextFactory<CinemaContext>
{
    public CinemaContext CreateDbContext(string[] args)
    {
        var options = new DbContextOptionsBuilder<CinemaContext>()
            .UseSqlite("Data Source=cinema.db")
            .Options;

        return new CinemaContext(options);
    }
}
