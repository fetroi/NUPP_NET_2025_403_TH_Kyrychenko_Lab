﻿using System.Text;
using Cinema.Domain.Models;
using Cinema.Infrastructure.Data;
using Microsoft.EntityFrameworkCore;

Console.OutputEncoding = Encoding.UTF8;

var options = new DbContextOptionsBuilder<CinemaContext>()
    .UseSqlite("Data Source=cinema.db")
    .Options;

using var context = new CinemaContext(options);
await context.Database.MigrateAsync();

// Seed
if (!context.Movies.Any())
{
    var movie = new Movie
    {
        Title = "Інтерстеллар",
        DurationMinutes = 169,
        Details = new MovieDetails
        {
            Genre = "Наукова фантастика",
            AgeRestriction = "12+"
        }
    };

    var hall = new Hall
    {
        Name = "Зал №1",
        SeatsCount = 120
    };

    var session = new Session
    {
        StartTime = DateTime.Today.AddHours(18),
        Movie = movie,
        Hall = hall,
        Tickets =
        {
            new Ticket { Price = 120 },
            new Ticket { Price = 120 }
        }
    };

    context.Sessions.Add(session);
    await context.SaveChangesAsync();
}

// Output
Console.WriteLine("🎬 КІНОТЕАТР\n");

var movies = await context.Movies
    .Include(m => m.Details)
    .Include(m => m.Sessions)
        .ThenInclude(s => s.Hall)
    .Include(m => m.Sessions)
        .ThenInclude(s => s.Tickets)
    .ToListAsync();

foreach (var m in movies)
{
    Console.WriteLine($"🎥 Фільм: {m.Title}");
    Console.WriteLine($"   Жанр: {m.Details?.Genre}");
    Console.WriteLine($"   Вікове обмеження: {m.Details?.AgeRestriction}");

    foreach (var s in m.Sessions)
    {
        Console.WriteLine($"   🎞 Сеанс: {s.StartTime}");
        Console.WriteLine($"      Зал: {s.Hall?.Name}");
        Console.WriteLine($"      Квитків: {s.Tickets.Count}");
    }

    Console.WriteLine();
}

Console.WriteLine("Натисніть будь-яку клавішу...");
Console.ReadKey();