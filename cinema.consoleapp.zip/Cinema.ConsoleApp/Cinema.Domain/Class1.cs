﻿namespace Cinema.Domain
{
    public class Class1
    {

    }
}
