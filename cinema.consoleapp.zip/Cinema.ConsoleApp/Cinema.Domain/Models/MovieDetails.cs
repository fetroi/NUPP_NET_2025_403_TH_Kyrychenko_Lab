﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cinema.Domain.Models;

public class MovieDetails
{
    public int Id { get; set; }   // PK = FK
    public string Genre { get; set; } = string.Empty;
    public string AgeRestriction { get; set; } = string.Empty;

    public Movie? Movie { get; set; }
}

