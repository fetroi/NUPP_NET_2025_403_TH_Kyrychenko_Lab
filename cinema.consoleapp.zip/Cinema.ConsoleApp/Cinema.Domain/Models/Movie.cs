﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cinema.Domain.Models;

public class Movie
{
    public int Id { get; set; }
    public string Title { get; set; } = string.Empty;
    public int DurationMinutes { get; set; }

    public MovieDetails? Details { get; set; }          // 1–1
    public List<Session> Sessions { get; set; } = new(); // 1–many
}

